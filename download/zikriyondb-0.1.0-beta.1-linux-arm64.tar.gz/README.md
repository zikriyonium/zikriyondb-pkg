# ZikriyonDB

A small, crash-safe SQL database with a built-in HTTP API, made for people who
build websites with plain HTML, CSS, JavaScript and PHP. One program, no
installation of drivers or libraries. It runs on Linux, macOS, Windows and
**Android (Termux)**, and can give every device its own public address
(`https://myshop.phone.example.com`) through a relay.

> Status: developer preview (v0.1). Do not put data you cannot lose into it
> without a tested backup routine. See "Limitations".

## Quick start

```sh
scripts/install.sh                      # builds and installs `zikriyon`
zikriyon init --dir ~/mydb              # creates config + database, prints your ADMIN key ONCE
zikriyon serve --config ~/mydb/zikriyon.json

(README ke andar teen-backtick wale blocks hain, isliye file ko editor me seedha paste karna.)

### `CHANGELOG.md`

```markdown
# Changelog

## 0.1.0 (developer preview)
- Crash-safe storage (write-ahead log, checksums), B+Tree, large values
- SQL: tables, indexes on primary keys, JOIN/LEFT JOIN, aggregates, transactions
- AUTOINCREMENT keys, DEFAULT NOW(), JSON/BLOB/DATETIME types
- HTTP API with API keys, table permissions, rate limits, CORS
- End-user accounts with row-level security policies
- Backups, integrity check, restore, process lock
- Relay tunnel for unique public addresses
- JavaScript and PHP clients (single files)

## License

ZikriyonDB is **source-available** under the [Business Source License 1.1](LICENSE) (`BUSL-1.1`). It is not an OSI "open source" license.
- Free for production use in your own websites, apps and products, including apps whose users sign up and store their own data.
- Not allowed without a commercial license: offering ZikriyonDB or its relay to third parties as a hosted database or tunnel service.
- Each version converts to the Apache License 2.0 four years after it is published.
- The JavaScript and PHP clients in `clients/` and the `examples/` are Apache-2.0, so you can embed them anywhere.
- Commercial licensing and ZikriyonDB Cloud: admin@zeaipc.info